/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllerImpl;

import controller.NoteController;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author linux
 */
public class NoteControllerImpl extends UnicastRemoteObject implements NoteController{
    private String note="empty";
    public NoteControllerImpl()throws RemoteException{
        //
    }
    @Override
    public void upload(String note) throws RemoteException {
        this.note=note;
    }

    @Override
    public String reload() throws RemoteException {
        return this.note;
    }
    
}
